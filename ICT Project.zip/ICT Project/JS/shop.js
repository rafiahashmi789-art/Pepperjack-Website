document.addEventListener("DOMContentLoaded", function () {
  // Cart Management Functions
  function getCart() {
    const cart = localStorage.getItem("pepperjackCart");
    return cart ? JSON.parse(cart) : [];
  }

  function saveCart(cart) {
    localStorage.setItem("pepperjackCart", JSON.stringify(cart));
    updateCartCount();
  }

  function updateCartCount() {
    const cart = getCart();
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const cartCountEl = document.getElementById("cartCount");
    if (cartCountEl) {
      cartCountEl.textContent = totalItems;
      cartCountEl.style.display = totalItems > 0 ? "flex" : "none";
    }
  }

  function addToCart(product) {
    const cart = getCart();
    const existingItem = cart.find((item) => item.id === product.id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      cart.push({
        id: product.id,
        name: product.name,
        price: product.price,
        quantity: 1,
        image: product.image,
      });
    }

    saveCart(cart);
    showNotification(product.name);
  }

  function showNotification(productName) {
    const existingNotif = document.querySelector(".cart-notification");
    if (existingNotif) {
      existingNotif.remove();
    }

    const notification = document.createElement("div");
    notification.className = "cart-notification";
    notification.innerHTML = `
      <div class="notification-content">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M20 6L9 17l-5-5"/>
        </svg>
        <span>${productName} added to cart!</span>
      </div>
    `;
    document.body.appendChild(notification);

    setTimeout(() => notification.classList.add("show"), 10);
    setTimeout(() => {
      notification.classList.remove("show");
      setTimeout(() => notification.remove(), 300);
    }, 3000);
  }

  // Initialize cart count
  updateCartCount();

  // Add to Cart Button Functionality
  const addToCartButtons = document.querySelectorAll(".add-to-cart-btn");
  addToCartButtons.forEach((button) => {
    button.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();

      const productCard = this.closest(".product-card");
      const product = {
        id: productCard.dataset.productId,
        name: productCard.dataset.productName,
        price: parseFloat(productCard.dataset.productPrice),
        image: productCard.dataset.productImage,
      };

      addToCart(product);

      this.classList.add("added");
      this.textContent = "Added!";
      setTimeout(() => {
        this.classList.remove("added");
        this.textContent = "Add to Cart";
      }, 1500);
    });
  });

  // Newsletter Form
  const newsletterForm = document.querySelector(".newsletter-form");
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const emailInput = this.querySelector(".newsletter-input");
      emailInput.value = "";
    });
  }

  // Announcement Button
  const announcementButton = document.querySelector(".announcement_button");
  if (announcementButton) {
    announcementButton.addEventListener("click", function () {
      window.location.href = "shop-all.html";
    });
  }
});
